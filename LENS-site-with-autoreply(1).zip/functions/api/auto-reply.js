// Cloudflare Pages Function: /api/auto-reply
// Sends an automatic "thanks for reaching out" email to whoever submits
// the LENS contact form, from hello@lensmediaco.co.in, via the SMTP2GO API.
//
// Requires an environment variable/secret named SMTP2GO_API_KEY to be set
// in the Cloudflare Pages project settings (Settings -> Environment variables).
// Never hardcode the API key here.

export async function onRequestPost(context) {
  const { request, env } = context;

  const jsonResponse = (body, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { 'Content-Type': 'application/json' }
    });

  let payloadIn;
  try {
    payloadIn = await request.json();
  } catch {
    return jsonResponse({ success: false, error: 'Invalid JSON body' }, 400);
  }

  const name = (payloadIn.name || '').toString().trim();
  const email = (payloadIn.email || '').toString().trim();

  if (!name || !email) {
    return jsonResponse({ success: false, error: 'Missing name or email' }, 400);
  }

  const apiKey = env.SMTP2GO_API_KEY;
  if (!apiKey) {
    return jsonResponse({ success: false, error: 'Server missing SMTP2GO_API_KEY' }, 500);
  }

  const emailPayload = {
    api_key: apiKey,
    sender: 'LENS Media <hello@lensmediaco.co.in>',
    to: [`${name} <${email}>`],
    subject: "We've got your message — LENS",
    text_body:
      `Hi ${name},\n\n` +
      `Thanks for reaching out to LENS. We've received your message and someone from our team will get back to you shortly.\n\n` +
      `In the meantime, feel free to look around lensmediaco.co.in.\n\n` +
      `Talk soon,\nLENS Media`,
    html_body:
      `<p>Hi ${name},</p>` +
      `<p>Thanks for reaching out to LENS. We've received your message and someone from our team will get back to you shortly.</p>` +
      `<p>In the meantime, feel free to look around <a href="https://lensmediaco.co.in">lensmediaco.co.in</a>.</p>` +
      `<p>Talk soon,<br>LENS Media</p>`
  };

  try {
    const res = await fetch('https://api.smtp2go.com/v3/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(emailPayload)
    });

    const data = await res.json();

    if (!res.ok || data?.data?.error) {
      return jsonResponse(
        { success: false, error: data?.data?.error || 'SMTP2GO rejected the request' },
        502
      );
    }

    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message || 'Unknown error' }, 500);
  }
}
